package app.steady.tracker.data.repository

import androidx.room.withTransaction
import app.steady.tracker.data.db.SteadyDatabase
import app.steady.tracker.data.db.dao.EntryDao
import app.steady.tracker.domain.model.Entry
import app.steady.tracker.domain.repository.EntryRepository
import app.steady.tracker.domain.util.TimeRanges
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.time.Instant
import java.time.LocalDate

class EntryRepositoryImpl(
    private val db: SteadyDatabase,
    private val dao: EntryDao,
) : EntryRepository {

    override fun observeForDay(date: LocalDate): Flow<List<Entry>> =
        observeBetween(TimeRanges.startOfDay(date), TimeRanges.endOfDayExclusive(date))

    override fun observeBetween(start: Instant, endExclusive: Instant): Flow<List<Entry>> =
        dao.observeBetween(start.toEpochMilli(), endExclusive.toEpochMilli())
            .map { list -> list.map { it.toDomain() } }

    override fun observeAll(): Flow<List<Entry>> =
        dao.observeAll().map { list -> list.map { it.toDomain() } }

    override fun observeLatest(): Flow<Entry?> =
        dao.observeLatest().map { it?.toDomain() }

    override fun observeCount(): Flow<Int> = dao.observeCount()

    override suspend fun get(id: Long): Entry? = dao.getById(id)?.toDomain()

    override suspend fun save(entry: Entry): Long = dao.upsert(entry.toEntity()).let { rowId ->
        if (entry.id == 0L) rowId else entry.id
    }

    override suspend fun delete(id: Long) = dao.deleteById(id)

    override suspend fun getAll(): List<Entry> = dao.getAll().map { it.toDomain() }

    override suspend fun replaceAll(entries: List<Entry>) {
        db.withTransaction {
            dao.deleteAll()
            dao.insertAll(entries.map { it.toEntity() })
        }
    }

    override suspend fun deleteAll() = dao.deleteAll()
}
