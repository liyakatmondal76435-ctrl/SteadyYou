package app.steady.tracker.data.repository

import androidx.room.withTransaction
import app.steady.tracker.data.db.SteadyDatabase
import app.steady.tracker.data.db.dao.UrgeDao
import app.steady.tracker.domain.model.Urge
import app.steady.tracker.domain.repository.UrgeRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class UrgeRepositoryImpl(
    private val db: SteadyDatabase,
    private val dao: UrgeDao,
) : UrgeRepository {

    override fun observeAll(): Flow<List<Urge>> =
        dao.observeAll().map { list -> list.map { it.toDomain() } }

    override fun observeResistedCount(): Flow<Int> = dao.observeResistedCount()

    override suspend fun save(urge: Urge): Long = dao.upsert(urge.toEntity()).let { rowId ->
        if (urge.id == 0L) rowId else urge.id
    }

    override suspend fun getAll(): List<Urge> = dao.getAll().map { it.toDomain() }

    override suspend fun replaceAll(urges: List<Urge>) {
        db.withTransaction {
            dao.deleteAll()
            dao.insertAll(urges.map { it.toEntity() })
        }
    }

    override suspend fun deleteAll() = dao.deleteAll()
}
