package app.steady.tracker.data.db

import androidx.room.migration.Migration

/**
 * Registry of schema migrations. Version 1 is the first release, so the list is empty.
 * When the schema changes, bump [SteadyDatabase] version, export the new schema JSON
 * (committed under app/schemas) and add a `Migration(from, to)` instance here.
 */
object Migrations {
    val ALL: Array<Migration> = emptyArray()
}
