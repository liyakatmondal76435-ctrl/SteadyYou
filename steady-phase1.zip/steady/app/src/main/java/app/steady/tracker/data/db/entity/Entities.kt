package app.steady.tracker.data.db.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "entries", indices = [Index("timestamp")])
data class EntryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    /** Epoch milliseconds (UTC). */
    val timestamp: Long,
    /** Stored as [app.steady.tracker.domain.model.Trigger] name; "trigger" is an SQL keyword. */
    val triggerType: String,
    val moodBefore: Int,
    val moodAfter: Int,
    val note: String?,
)

@Entity(tableName = "urges", indices = [Index("timestamp")])
data class UrgeEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long,
    val resisted: Boolean,
    val durationSeconds: Int,
    val activity: String?,
)

@Entity(tableName = "achievements")
data class AchievementEntity(
    @PrimaryKey val key: String,
    val unlockedAt: Long,
    val notified: Boolean,
)
