package app.steady.tracker.di

import androidx.room.Room
import app.steady.tracker.data.db.Migrations
import app.steady.tracker.data.db.SteadyDatabase
import app.steady.tracker.data.repository.AchievementRepositoryImpl
import app.steady.tracker.data.repository.DataWiperImpl
import app.steady.tracker.data.repository.EntryRepositoryImpl
import app.steady.tracker.data.repository.UrgeRepositoryImpl
import app.steady.tracker.data.settings.SettingsRepositoryImpl
import app.steady.tracker.domain.repository.AchievementRepository
import app.steady.tracker.domain.repository.DataWiper
import app.steady.tracker.domain.repository.EntryRepository
import app.steady.tracker.domain.repository.SettingsRepository
import app.steady.tracker.domain.repository.UrgeRepository
import org.koin.android.ext.koin.androidContext
import org.koin.dsl.module

val databaseModule = module {
    single {
        Room.databaseBuilder(androidContext(), SteadyDatabase::class.java, SteadyDatabase.NAME)
            .addMigrations(*Migrations.ALL)
            .build()
    }
    single { get<SteadyDatabase>().entryDao() }
    single { get<SteadyDatabase>().urgeDao() }
    single { get<SteadyDatabase>().achievementDao() }
}

val dataModule = module {
    single<SettingsRepository> { SettingsRepositoryImpl(androidContext()) }
    single<EntryRepository> { EntryRepositoryImpl(get(), get()) }
    single<UrgeRepository> { UrgeRepositoryImpl(get(), get()) }
    single<AchievementRepository> { AchievementRepositoryImpl(get(), get()) }
    single<DataWiper> { DataWiperImpl(get(), get()) }
}

val appModules = listOf(databaseModule, dataModule)
