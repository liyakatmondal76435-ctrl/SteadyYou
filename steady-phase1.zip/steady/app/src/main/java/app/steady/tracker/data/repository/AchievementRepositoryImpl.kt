package app.steady.tracker.data.repository

import androidx.room.withTransaction
import app.steady.tracker.data.db.SteadyDatabase
import app.steady.tracker.data.db.dao.AchievementDao
import app.steady.tracker.data.db.entity.AchievementEntity
import app.steady.tracker.domain.model.UnlockedAchievement
import app.steady.tracker.domain.repository.AchievementRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.time.Instant

class AchievementRepositoryImpl(
    private val db: SteadyDatabase,
    private val dao: AchievementDao,
) : AchievementRepository {

    override fun observeAll(): Flow<List<UnlockedAchievement>> =
        dao.observeAll().map { list -> list.map { it.toDomain() } }

    override suspend fun unlock(key: String, at: Instant): Boolean =
        dao.insertIfAbsent(AchievementEntity(key, at.toEpochMilli(), notified = false)) != -1L

    override suspend fun markNotified(key: String) = dao.markNotified(key)

    override suspend fun getAll(): List<UnlockedAchievement> = dao.getAll().map { it.toDomain() }

    override suspend fun replaceAll(items: List<UnlockedAchievement>) {
        db.withTransaction {
            dao.deleteAll()
            dao.insertAll(items.map { it.toEntity() })
        }
    }

    override suspend fun deleteAll() = dao.deleteAll()
}
