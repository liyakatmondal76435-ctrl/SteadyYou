package app.steady.tracker.domain.util

import java.time.DayOfWeek
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.TemporalAdjusters

/** Calendar helpers; every function takes a [ZoneId] so logic stays testable. */
object TimeRanges {
    fun startOfDay(date: LocalDate, zone: ZoneId = ZoneId.systemDefault()): Instant =
        date.atStartOfDay(zone).toInstant()

    fun endOfDayExclusive(date: LocalDate, zone: ZoneId = ZoneId.systemDefault()): Instant =
        date.plusDays(1).atStartOfDay(zone).toInstant()

    fun startOfWeek(date: LocalDate, firstDay: DayOfWeek = DayOfWeek.MONDAY): LocalDate =
        date.with(TemporalAdjusters.previousOrSame(firstDay))

    fun startOfMonth(date: LocalDate): LocalDate = date.withDayOfMonth(1)

    fun startOfYear(date: LocalDate): LocalDate = date.withDayOfYear(1)

    fun toLocalDate(instant: Instant, zone: ZoneId = ZoneId.systemDefault()): LocalDate =
        instant.atZone(zone).toLocalDate()
}
