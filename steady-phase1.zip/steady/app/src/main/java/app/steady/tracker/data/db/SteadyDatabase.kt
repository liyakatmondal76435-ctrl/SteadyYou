package app.steady.tracker.data.db

import androidx.room.Database
import androidx.room.RoomDatabase
import app.steady.tracker.data.db.dao.AchievementDao
import app.steady.tracker.data.db.dao.EntryDao
import app.steady.tracker.data.db.dao.UrgeDao
import app.steady.tracker.data.db.entity.AchievementEntity
import app.steady.tracker.data.db.entity.EntryEntity
import app.steady.tracker.data.db.entity.UrgeEntity

@Database(
    entities = [EntryEntity::class, UrgeEntity::class, AchievementEntity::class],
    version = 1,
    exportSchema = true,
)
abstract class SteadyDatabase : RoomDatabase() {
    abstract fun entryDao(): EntryDao
    abstract fun urgeDao(): UrgeDao
    abstract fun achievementDao(): AchievementDao

    companion object {
        const val NAME = "steady.db"
    }
}
