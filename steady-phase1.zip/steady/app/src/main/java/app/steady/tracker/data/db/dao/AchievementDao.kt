package app.steady.tracker.data.db.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import app.steady.tracker.data.db.entity.AchievementEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface AchievementDao {
    @Query("SELECT * FROM achievements ORDER BY unlockedAt ASC")
    fun observeAll(): Flow<List<AchievementEntity>>

    @Query("SELECT * FROM achievements ORDER BY unlockedAt ASC")
    suspend fun getAll(): List<AchievementEntity>

    /** Returns -1 when the badge already exists, so callers can tell a new unlock apart. */
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertIfAbsent(item: AchievementEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<AchievementEntity>)

    @Query("UPDATE achievements SET notified = 1 WHERE `key` = :key")
    suspend fun markNotified(key: String)

    @Query("DELETE FROM achievements")
    suspend fun deleteAll()
}
