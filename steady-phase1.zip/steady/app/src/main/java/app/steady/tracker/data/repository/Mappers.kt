package app.steady.tracker.data.repository

import app.steady.tracker.data.db.entity.AchievementEntity
import app.steady.tracker.data.db.entity.EntryEntity
import app.steady.tracker.data.db.entity.UrgeEntity
import app.steady.tracker.domain.model.Entry
import app.steady.tracker.domain.model.Mood
import app.steady.tracker.domain.model.Trigger
import app.steady.tracker.domain.model.UnlockedAchievement
import app.steady.tracker.domain.model.Urge
import java.time.Instant

internal fun EntryEntity.toDomain() = Entry(
    id = id,
    timestamp = Instant.ofEpochMilli(timestamp),
    trigger = Trigger.fromName(triggerType),
    moodBefore = Mood.clamp(moodBefore),
    moodAfter = Mood.clamp(moodAfter),
    note = note,
)

internal fun Entry.toEntity() = EntryEntity(
    id = id,
    timestamp = timestamp.toEpochMilli(),
    triggerType = trigger.name,
    moodBefore = Mood.clamp(moodBefore),
    moodAfter = Mood.clamp(moodAfter),
    note = note?.trim()?.takeIf { it.isNotEmpty() },
)

internal fun UrgeEntity.toDomain() = Urge(
    id = id,
    timestamp = Instant.ofEpochMilli(timestamp),
    resisted = resisted,
    durationSeconds = durationSeconds,
    activity = activity,
)

internal fun Urge.toEntity() = UrgeEntity(
    id = id,
    timestamp = timestamp.toEpochMilli(),
    resisted = resisted,
    durationSeconds = durationSeconds.coerceAtLeast(0),
    activity = activity,
)

internal fun AchievementEntity.toDomain() = UnlockedAchievement(
    key = key,
    unlockedAt = Instant.ofEpochMilli(unlockedAt),
    notified = notified,
)

internal fun UnlockedAchievement.toEntity() = AchievementEntity(
    key = key,
    unlockedAt = unlockedAt.toEpochMilli(),
    notified = notified,
)
