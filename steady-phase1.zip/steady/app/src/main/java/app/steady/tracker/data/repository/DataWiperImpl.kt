package app.steady.tracker.data.repository

import androidx.room.withTransaction
import app.steady.tracker.data.db.SteadyDatabase
import app.steady.tracker.domain.repository.DataWiper
import app.steady.tracker.domain.repository.SettingsRepository

class DataWiperImpl(
    private val db: SteadyDatabase,
    private val settings: SettingsRepository,
) : DataWiper {
    override suspend fun wipeEverything() {
        db.withTransaction {
            db.entryDao().deleteAll()
            db.urgeDao().deleteAll()
            db.achievementDao().deleteAll()
        }
        settings.resetAll()
    }
}
