package app.steady.tracker.domain.repository

import app.steady.tracker.domain.model.AppSettings
import app.steady.tracker.domain.model.Entry
import app.steady.tracker.domain.model.UnlockedAchievement
import app.steady.tracker.domain.model.Urge
import kotlinx.coroutines.flow.Flow
import java.time.Instant
import java.time.LocalDate

interface EntryRepository {
    fun observeForDay(date: LocalDate): Flow<List<Entry>>
    fun observeBetween(start: Instant, endExclusive: Instant): Flow<List<Entry>>
    fun observeAll(): Flow<List<Entry>>
    fun observeLatest(): Flow<Entry?>
    fun observeCount(): Flow<Int>
    suspend fun get(id: Long): Entry?
    /** Inserts when [Entry.id] is 0, otherwise updates. Returns the row id. */
    suspend fun save(entry: Entry): Long
    suspend fun delete(id: Long)
    suspend fun getAll(): List<Entry>
    suspend fun replaceAll(entries: List<Entry>)
    suspend fun deleteAll()
}

interface UrgeRepository {
    fun observeAll(): Flow<List<Urge>>
    fun observeResistedCount(): Flow<Int>
    suspend fun save(urge: Urge): Long
    suspend fun getAll(): List<Urge>
    suspend fun replaceAll(urges: List<Urge>)
    suspend fun deleteAll()
}

interface AchievementRepository {
    fun observeAll(): Flow<List<UnlockedAchievement>>
    /** Returns true only when the badge was newly unlocked by this call. */
    suspend fun unlock(key: String, at: Instant): Boolean
    suspend fun markNotified(key: String)
    suspend fun getAll(): List<UnlockedAchievement>
    suspend fun replaceAll(items: List<UnlockedAchievement>)
    suspend fun deleteAll()
}

interface SettingsRepository {
    val settings: Flow<AppSettings>
    suspend fun update(transform: (AppSettings) -> AppSettings)
    /** Stores a salted hash of [pin]; the caller chooses the lock type. */
    suspend fun setPin(pin: String)
    suspend fun verifyPin(pin: String): Boolean
    suspend fun clearLock()
    suspend fun resetAll()
}

/** Wipes every table and preference in one call; used by "Delete all data". */
interface DataWiper {
    suspend fun wipeEverything()
}
