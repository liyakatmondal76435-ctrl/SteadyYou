package app.steady.tracker.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.MaterialExpressiveTheme
import androidx.compose.material3.MotionScheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import app.steady.tracker.domain.model.AppSettings
import app.steady.tracker.domain.model.ColorPalette
import app.steady.tracker.domain.model.ThemeMode

private class Swatch(
    val primary: Color,
    val onPrimary: Color,
    val primaryContainer: Color,
    val onPrimaryContainer: Color,
    val secondary: Color,
    val tertiary: Color,
)

private fun swatch(palette: ColorPalette, dark: Boolean): Swatch = when (palette) {
    ColorPalette.OCEAN ->
        if (dark) Swatch(Color(0xFF8DCDFF), Color(0xFF00344D), Color(0xFF004B6E), Color(0xFFC6E7FF), Color(0xFFB5C9DB), Color(0xFFCDC0E9))
        else Swatch(Color(0xFF1B6B93), Color.White, Color(0xFFC6E7FF), Color(0xFF001E2E), Color(0xFF4E6070), Color(0xFF63597C))
    ColorPalette.FOREST ->
        if (dark) Swatch(Color(0xFF96D49E), Color(0xFF00391A), Color(0xFF145229), Color(0xFFB1F1B8), Color(0xFFB7CCB5), Color(0xFFA2CED5))
        else Swatch(Color(0xFF2E6B3E), Color.White, Color(0xFFB1F1B8), Color(0xFF00210B), Color(0xFF516350), Color(0xFF39656B))
    ColorPalette.DUSK ->
        if (dark) Swatch(Color(0xFFD0BCFF), Color(0xFF381E72), Color(0xFF4F378B), Color(0xFFEADDFF), Color(0xFFCCC2DC), Color(0xFFEFB8C8))
        else Swatch(Color(0xFF6750A4), Color.White, Color(0xFFEADDFF), Color(0xFF21005D), Color(0xFF625B71), Color(0xFF7D5260))
    ColorPalette.SAND ->
        if (dark) Swatch(Color(0xFFFFB871), Color(0xFF4A2800), Color(0xFF693C00), Color(0xFFFFDCBE), Color(0xFFE2C1A6), Color(0xFFC4CC93))
        else Swatch(Color(0xFF8A5100), Color.White, Color(0xFFFFDCBE), Color(0xFF2C1600), Color(0xFF735944), Color(0xFF5B6236))
}

private fun paletteScheme(palette: ColorPalette, dark: Boolean): ColorScheme {
    val s = swatch(palette, dark)
    return if (dark) {
        darkColorScheme(
            primary = s.primary, onPrimary = s.onPrimary,
            primaryContainer = s.primaryContainer, onPrimaryContainer = s.onPrimaryContainer,
            secondary = s.secondary, tertiary = s.tertiary,
        )
    } else {
        lightColorScheme(
            primary = s.primary, onPrimary = s.onPrimary,
            primaryContainer = s.primaryContainer, onPrimaryContainer = s.onPrimaryContainer,
            secondary = s.secondary, tertiary = s.tertiary,
        )
    }
}

private fun ColorScheme.toAmoled(): ColorScheme = copy(
    background = Color.Black,
    surface = Color.Black,
    surfaceDim = Color.Black,
    surfaceContainerLowest = Color.Black,
    surfaceContainerLow = Color(0xFF0A0A0A),
    surfaceContainer = Color(0xFF111111),
    surfaceContainerHigh = Color(0xFF181818),
    surfaceContainerHighest = Color(0xFF202020),
)

@OptIn(ExperimentalMaterial3ExpressiveApi::class)
@Composable
fun SteadyTheme(
    settings: AppSettings,
    content: @Composable () -> Unit,
) {
    val dark = when (settings.themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK, ThemeMode.AMOLED -> true
    }
    val context = LocalContext.current
    val useDynamic = settings.dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
    var scheme = when {
        useDynamic && dark -> dynamicDarkColorScheme(context)
        useDynamic -> dynamicLightColorScheme(context)
        else -> paletteScheme(settings.palette, dark)
    }
    if (dark && settings.themeMode == ThemeMode.AMOLED) scheme = scheme.toAmoled()

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window ?: return@SideEffect
            val controller = WindowCompat.getInsetsController(window, view)
            controller.isAppearanceLightStatusBars = !dark
            controller.isAppearanceLightNavigationBars = !dark
        }
    }

    MaterialExpressiveTheme(
        colorScheme = scheme,
        motionScheme = MotionScheme.expressive(),
        shapes = Shapes(),
        typography = Typography(),
        content = content,
    )
}
