package app.steady.tracker

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.steady.tracker.domain.model.AppSettings
import app.steady.tracker.domain.repository.EntryRepository
import app.steady.tracker.domain.repository.SettingsRepository
import app.steady.tracker.ui.theme.SteadyTheme
import org.koin.android.ext.android.inject

/**
 * Phase 1 host activity. It wires theme, edge-to-edge, FLAG_SECURE and the data layer;
 * navigation and the real screens replace [BootstrapScreen] in the next phases.
 */
class MainActivity : ComponentActivity() {

    private val settingsRepository: SettingsRepository by inject()
    private val entryRepository: EntryRepository by inject()

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        // Blocks screenshots, screen recording and the recents thumbnail on every screen.
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)

        setContent {
            val settings by settingsRepository.settings.collectAsStateWithLifecycle(initialValue = AppSettings())
            val count by entryRepository.observeCount().collectAsStateWithLifecycle(initialValue = 0)
            SteadyTheme(settings) {
                BootstrapScreen(entryCount = count)
            }
        }
    }
}

@Composable
private fun BootstrapScreen(entryCount: Int) {
    Scaffold { padding ->
        Surface(modifier = Modifier.fillMaxSize().padding(padding)) {
            Column(
                modifier = Modifier.fillMaxSize().padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterVertically),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(stringResource(R.string.bootstrap_title), style = MaterialTheme.typography.displaySmall)
                Text(stringResource(R.string.bootstrap_subtitle), style = MaterialTheme.typography.bodyLarge)
                Text(
                    stringResource(R.string.bootstrap_entries, entryCount),
                    style = MaterialTheme.typography.labelLarge,
                )
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
private fun BootstrapPreview() {
    SteadyTheme(AppSettings(dynamicColor = false)) { BootstrapScreen(entryCount = 3) }
}
