package app.steady.tracker.data.settings

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import app.steady.tracker.data.security.PinHasher
import app.steady.tracker.domain.model.AppIcon
import app.steady.tracker.domain.model.AppSettings
import app.steady.tracker.domain.model.ColorPalette
import app.steady.tracker.domain.model.GoalMode
import app.steady.tracker.domain.model.LockType
import app.steady.tracker.domain.model.ThemeMode
import app.steady.tracker.domain.repository.SettingsRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.io.IOException

private val Context.settingsDataStore: DataStore<Preferences> by preferencesDataStore(name = "steady_settings")

private object Keys {
    val ONBOARDING = booleanPreferencesKey("onboarding_complete")
    val GOAL = stringPreferencesKey("goal_mode")
    val BASELINE = intPreferencesKey("baseline_per_week")
    val LIMIT = intPreferencesKey("daily_limit")
    val LOCK = stringPreferencesKey("lock_type")
    val PIN_HASH = stringPreferencesKey("pin_hash")
    val PIN_SALT = stringPreferencesKey("pin_salt")
    val THEME = stringPreferencesKey("theme_mode")
    val DYNAMIC = booleanPreferencesKey("dynamic_color")
    val PALETTE = stringPreferencesKey("palette")
    val ICON = stringPreferencesKey("app_icon")
    val HIDE_WIDGET = booleanPreferencesKey("hide_widget_numbers")
    val REMINDERS = booleanPreferencesKey("reminders_enabled")
    val REMINDER_H = intPreferencesKey("reminder_hour")
    val REMINDER_M = intPreferencesKey("reminder_minute")
    val ACH_NOTIFY = booleanPreferencesKey("achievement_notifications")
    val LANGUAGE = stringPreferencesKey("language_tag")
}

private inline fun <reified E : Enum<E>> String?.toEnum(default: E): E =
    enumValues<E>().firstOrNull { it.name == this } ?: default

private fun Preferences.toSettings(): AppSettings {
    val d = AppSettings()
    return AppSettings(
        onboardingComplete = this[Keys.ONBOARDING] ?: d.onboardingComplete,
        goalMode = this[Keys.GOAL].toEnum(d.goalMode),
        baselinePerWeek = this[Keys.BASELINE] ?: d.baselinePerWeek,
        dailyLimit = this[Keys.LIMIT] ?: d.dailyLimit,
        lockType = this[Keys.LOCK].toEnum(d.lockType),
        pinHash = this[Keys.PIN_HASH],
        pinSalt = this[Keys.PIN_SALT],
        themeMode = this[Keys.THEME].toEnum(d.themeMode),
        dynamicColor = this[Keys.DYNAMIC] ?: d.dynamicColor,
        palette = this[Keys.PALETTE].toEnum(d.palette),
        appIcon = this[Keys.ICON].toEnum(d.appIcon),
        hideWidgetNumbers = this[Keys.HIDE_WIDGET] ?: d.hideWidgetNumbers,
        remindersEnabled = this[Keys.REMINDERS] ?: d.remindersEnabled,
        reminderHour = this[Keys.REMINDER_H] ?: d.reminderHour,
        reminderMinute = this[Keys.REMINDER_M] ?: d.reminderMinute,
        achievementNotifications = this[Keys.ACH_NOTIFY] ?: d.achievementNotifications,
        languageTag = this[Keys.LANGUAGE] ?: d.languageTag,
    )
}

private fun MutablePreferences.write(s: AppSettings) {
    this[Keys.ONBOARDING] = s.onboardingComplete
    this[Keys.GOAL] = s.goalMode.name
    this[Keys.BASELINE] = s.baselinePerWeek.coerceAtLeast(0)
    this[Keys.LIMIT] = s.dailyLimit.coerceAtLeast(0)
    this[Keys.LOCK] = s.lockType.name
    if (s.pinHash != null) this[Keys.PIN_HASH] = s.pinHash else remove(Keys.PIN_HASH)
    if (s.pinSalt != null) this[Keys.PIN_SALT] = s.pinSalt else remove(Keys.PIN_SALT)
    this[Keys.THEME] = s.themeMode.name
    this[Keys.DYNAMIC] = s.dynamicColor
    this[Keys.PALETTE] = s.palette.name
    this[Keys.ICON] = s.appIcon.name
    this[Keys.HIDE_WIDGET] = s.hideWidgetNumbers
    this[Keys.REMINDERS] = s.remindersEnabled
    this[Keys.REMINDER_H] = s.reminderHour.coerceIn(0, 23)
    this[Keys.REMINDER_M] = s.reminderMinute.coerceIn(0, 59)
    this[Keys.ACH_NOTIFY] = s.achievementNotifications
    this[Keys.LANGUAGE] = s.languageTag
}

class SettingsRepositoryImpl(private val context: Context) : SettingsRepository {

    private val store get() = context.settingsDataStore

    override val settings: Flow<AppSettings> = store.data
        .catch { error -> if (error is IOException) emit(emptyPreferences()) else throw error }
        .map { it.toSettings() }

    override suspend fun update(transform: (AppSettings) -> AppSettings) {
        store.edit { prefs -> prefs.write(transform(prefs.toSettings())) }
    }

    override suspend fun setPin(pin: String) {
        val salt = PinHasher.newSalt()
        val hash = PinHasher.hash(pin, salt)
        update { it.copy(pinHash = hash, pinSalt = salt) }
    }

    override suspend fun verifyPin(pin: String): Boolean {
        val current = settings.first()
        val hash = current.pinHash ?: return false
        val salt = current.pinSalt ?: return false
        return PinHasher.matches(pin, salt, hash)
    }

    override suspend fun clearLock() {
        update { it.copy(lockType = LockType.NONE, pinHash = null, pinSalt = null) }
    }

    override suspend fun resetAll() {
        store.edit { it.clear() }
    }
}
