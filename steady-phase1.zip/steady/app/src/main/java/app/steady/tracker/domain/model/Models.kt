package app.steady.tracker.domain.model

import java.time.Instant

enum class Trigger {
    STRESS, BOREDOM, ROUTINE, LONELINESS, LATE_NIGHT, SOCIAL_MEDIA, OTHER;

    companion object {
        fun fromName(name: String?): Trigger =
            entries.firstOrNull { it.name == name } ?: OTHER
    }
}

/** Mood scale used before and after an entry: 1 (low) .. 5 (high). */
object Mood {
    const val MIN = 1
    const val MAX = 5
    const val DEFAULT = 3
    fun clamp(value: Int): Int = value.coerceIn(MIN, MAX)
}

data class Entry(
    val id: Long = 0,
    val timestamp: Instant,
    val trigger: Trigger = Trigger.OTHER,
    val moodBefore: Int = Mood.DEFAULT,
    val moodAfter: Int = Mood.DEFAULT,
    val note: String? = null,
)

/** A logged urge. [resisted] = true when the person chose to let it pass. */
data class Urge(
    val id: Long = 0,
    val timestamp: Instant,
    val resisted: Boolean,
    val durationSeconds: Int,
    val activity: String? = null,
)

data class UnlockedAchievement(
    val key: String,
    val unlockedAt: Instant,
    val notified: Boolean,
)

enum class GoalMode { TRACK_ONLY, REDUCE, ABSTAIN }
enum class ThemeMode { SYSTEM, LIGHT, DARK, AMOLED }
enum class ColorPalette { OCEAN, FOREST, DUSK, SAND }
enum class LockType { NONE, PIN, BIOMETRIC }

/** Neutral launcher identities; each maps to an activity-alias added in a later phase. */
enum class AppIcon { DEFAULT, NOTES, COMPASS, CLOCK }

data class AppSettings(
    val onboardingComplete: Boolean = false,
    val goalMode: GoalMode = GoalMode.TRACK_ONLY,
    val baselinePerWeek: Int = 0,
    /** 0 means "no daily limit". */
    val dailyLimit: Int = 0,
    val lockType: LockType = LockType.NONE,
    val pinHash: String? = null,
    val pinSalt: String? = null,
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val dynamicColor: Boolean = true,
    val palette: ColorPalette = ColorPalette.OCEAN,
    val appIcon: AppIcon = AppIcon.DEFAULT,
    val hideWidgetNumbers: Boolean = false,
    val remindersEnabled: Boolean = false,
    val reminderHour: Int = 21,
    val reminderMinute: Int = 0,
    val achievementNotifications: Boolean = true,
    /** BCP-47 tag, empty = follow the system language. */
    val languageTag: String = "",
)
