package app.steady.tracker

import android.app.Application
import app.steady.tracker.di.appModules
import org.koin.android.ext.koin.androidContext
import org.koin.core.context.startKoin

class SteadyApp : Application() {
    override fun onCreate() {
        super.onCreate()
        startKoin {
            androidContext(this@SteadyApp)
            modules(appModules)
        }
    }
}
