package app.steady.tracker.data.db.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Upsert
import app.steady.tracker.data.db.entity.UrgeEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface UrgeDao {
    @Query("SELECT * FROM urges ORDER BY timestamp DESC")
    fun observeAll(): Flow<List<UrgeEntity>>

    @Query("SELECT COUNT(*) FROM urges WHERE resisted = 1")
    fun observeResistedCount(): Flow<Int>

    @Query("SELECT * FROM urges ORDER BY timestamp ASC")
    suspend fun getAll(): List<UrgeEntity>

    @Upsert
    suspend fun upsert(urge: UrgeEntity): Long

    @Insert
    suspend fun insertAll(urges: List<UrgeEntity>)

    @Query("DELETE FROM urges")
    suspend fun deleteAll()
}
