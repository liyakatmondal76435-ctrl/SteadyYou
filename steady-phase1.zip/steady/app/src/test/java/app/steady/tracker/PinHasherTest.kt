package app.steady.tracker

import app.steady.tracker.data.security.PinHasher
import app.steady.tracker.domain.model.Trigger
import app.steady.tracker.domain.util.TimeRanges
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.ZoneOffset

class PinHasherTest {
    @Test
    fun correctPinMatches() {
        val salt = PinHasher.newSalt()
        val hash = PinHasher.hash("4821", salt)
        assertTrue(PinHasher.matches("4821", salt, hash))
    }

    @Test
    fun wrongPinDoesNotMatch() {
        val salt = PinHasher.newSalt()
        val hash = PinHasher.hash("4821", salt)
        assertFalse(PinHasher.matches("4822", salt, hash))
    }

    @Test
    fun saltsDiffer() {
        assertNotEquals(PinHasher.newSalt(), PinHasher.newSalt())
    }
}

class DomainUtilTest {
    @Test
    fun unknownTriggerFallsBackToOther() {
        assertEquals(Trigger.OTHER, Trigger.fromName("nonsense"))
        assertEquals(Trigger.OTHER, Trigger.fromName(null))
        assertEquals(Trigger.STRESS, Trigger.fromName("STRESS"))
    }

    @Test
    fun dayRangeIsTwentyFourHoursInUtc() {
        val date = LocalDate.of(2026, 3, 10)
        val start = TimeRanges.startOfDay(date, ZoneOffset.UTC)
        val end = TimeRanges.endOfDayExclusive(date, ZoneOffset.UTC)
        assertEquals(24 * 60 * 60, end.epochSecond - start.epochSecond)
    }

    @Test
    fun weekStartsOnMonday() {
        val wednesday = LocalDate.of(2026, 11, 4)
        assertEquals(LocalDate.of(2026, 11, 2), TimeRanges.startOfWeek(wednesday, DayOfWeek.MONDAY))
    }
}
