package app.steady.tracker.data

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import app.steady.tracker.data.db.SteadyDatabase
import app.steady.tracker.data.db.dao.AchievementDao
import app.steady.tracker.data.db.dao.EntryDao
import app.steady.tracker.data.db.dao.UrgeDao
import app.steady.tracker.data.db.entity.AchievementEntity
import app.steady.tracker.data.db.entity.EntryEntity
import app.steady.tracker.data.db.entity.UrgeEntity
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNull
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class EntryDaoTest {

    private lateinit var db: SteadyDatabase
    private lateinit var entries: EntryDao
    private lateinit var urges: UrgeDao
    private lateinit var achievements: AchievementDao

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, SteadyDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        entries = db.entryDao()
        urges = db.urgeDao()
        achievements = db.achievementDao()
    }

    @After
    fun tearDown() = db.close()

    private fun entry(ts: Long, trigger: String = "STRESS") =
        EntryEntity(timestamp = ts, triggerType = trigger, moodBefore = 2, moodAfter = 4, note = null)

    @Test
    fun insertAndReadBack() = runTest {
        val id = entries.upsert(entry(1_000))
        val loaded = entries.getById(id)
        assertEquals(1_000L, loaded?.timestamp)
        assertEquals("STRESS", loaded?.triggerType)
    }

    @Test
    fun observeBetweenIsStartInclusiveEndExclusiveAndNewestFirst() = runTest {
        entries.insertAll(listOf(entry(100), entry(200), entry(300), entry(400)))
        val result = entries.observeBetween(200, 400).first()
        assertEquals(listOf(300L, 200L), result.map { it.timestamp })
    }

    @Test
    fun upsertUpdatesExistingRow() = runTest {
        val id = entries.upsert(entry(500))
        entries.upsert(entry(500, "BOREDOM").copy(id = id))
        assertEquals(1, entries.observeCount().first())
        assertEquals("BOREDOM", entries.getById(id)?.triggerType)
    }

    @Test
    fun deleteByIdRemovesOnlyThatRow() = runTest {
        val a = entries.upsert(entry(1))
        val b = entries.upsert(entry(2))
        entries.deleteById(a)
        assertNull(entries.getById(a))
        assertNotEquals(null, entries.getById(b))
    }

    @Test
    fun latestReturnsMostRecentEntry() = runTest {
        entries.insertAll(listOf(entry(10), entry(30), entry(20)))
        assertEquals(30L, entries.observeLatest().first()?.timestamp)
    }

    @Test
    fun countBetweenCountsWindowOnly() = runTest {
        entries.insertAll(listOf(entry(1), entry(2), entry(3), entry(10)))
        assertEquals(3, entries.observeCountBetween(0, 5).first())
    }

    @Test
    fun resistedCountIgnoresOtherUrges() = runTest {
        urges.upsert(UrgeEntity(timestamp = 1, resisted = true, durationSeconds = 120, activity = "Walk"))
        urges.upsert(UrgeEntity(timestamp = 2, resisted = false, durationSeconds = 60, activity = null))
        urges.upsert(UrgeEntity(timestamp = 3, resisted = true, durationSeconds = 90, activity = null))
        assertEquals(2, urges.observeResistedCount().first())
    }

    @Test
    fun achievementInsertIsIdempotent() = runTest {
        val first = achievements.insertIfAbsent(AchievementEntity("streak_3", 1_000, false))
        val second = achievements.insertIfAbsent(AchievementEntity("streak_3", 2_000, false))
        assertNotEquals(-1L, first)
        assertEquals(-1L, second)
        assertEquals(1_000L, achievements.getAll().single().unlockedAt)
    }

    @Test
    fun markNotifiedFlipsFlag() = runTest {
        achievements.insertIfAbsent(AchievementEntity("streak_7", 1_000, false))
        achievements.markNotified("streak_7")
        assertEquals(true, achievements.getAll().single().notified)
    }

    @Test
    fun deleteAllClearsEntries() = runTest {
        entries.insertAll(listOf(entry(1), entry(2)))
        entries.deleteAll()
        assertEquals(0, entries.observeCount().first())
    }
}
