-keepattributes *Annotation*, InnerClasses, Signature, RuntimeVisibleAnnotations

# kotlinx.serialization
-keepclassmembers class app.steady.tracker.** {
    *** Companion;
}
-keepclasseswithmembers class app.steady.tracker.** {
    kotlinx.serialization.KSerializer serializer(...);
}
-keep,includedescriptorclasses class app.steady.tracker.**$$serializer { *; }

# Room-generated code is kept by the Room consumer rules.
