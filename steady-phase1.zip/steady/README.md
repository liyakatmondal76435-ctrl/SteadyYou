# Steady

A private, local-only routine tracker for adults (18+). Log entries, understand patterns,
and optionally work toward a reduction goal. All copy is clinical and non-judgmental, and the
app makes no medical claims.

If this feels out of control, consider talking to a professional.

## Privacy by design
- No `INTERNET` permission (explicitly removed from the merged manifest), no analytics.
- `allowBackup=false`, data-extraction rules exclude everything from cloud backup and device transfer.
- `FLAG_SECURE` on the activity: no screenshots, screen recording or recents thumbnail.
- Neutral app name, icon and notification wording.
- Optional PIN (salted PBKDF2) or biometric lock.

## Stack
Kotlin, Jetpack Compose, Material 3 Expressive, MVVM with data / domain / ui layers,
Room (KSP, exported schemas), DataStore, Koin, Navigation Compose, Coroutines + StateFlow,
Glance, WorkManager, kotlinx.serialization. `minSdk 26`, `compileSdk/targetSdk 36`.

## Build
Requirements: JDK 17 and Android Studio (current stable) or the Android SDK command-line tools.

1. Open the folder in Android Studio and let it sync, or from a terminal run
   `gradle wrapper --gradle-version 8.14.3` once to generate the Gradle wrapper.
2. Debug APK: `./gradlew assembleDebug`
   (output: `app/build/outputs/apk/debug/app-debug.apk`).
3. Unit tests: `./gradlew testDebugUnitTest`
4. Room DAO tests (device or emulator): `./gradlew connectedDebugAndroidTest`
5. Release build with R8 and resource shrinking: `./gradlew assembleRelease`
   (sign it with your own keystore; no keys are committed).

## CI
`.github/workflows/build.yml` runs unit tests, builds the debug APK on every push to `main`
and uploads it as the `steady-debug-apk` artifact.

## Project layout
```
app/src/main/java/app/steady/tracker/
  data/    Room database, DAOs, repositories, DataStore settings, PIN hashing
  domain/  models, repository interfaces, time helpers
  di/      Koin modules
  ui/      theme and (in later phases) screens
```
Room schemas are exported to `app/schemas/` and committed so migrations can be tested.

## Status
Phase 1 (project setup + database + settings + theme) is complete. Home and logging,
analytics, and the remaining screens follow.
